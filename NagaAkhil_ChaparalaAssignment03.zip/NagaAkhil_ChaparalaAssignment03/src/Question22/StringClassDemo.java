package Question22;

public class StringClassDemo {
    public static void main(String[] args) {
        String str1 = "Welcome";
        System.out.println("Original string: " + str1);

        // Appending a string to the original string
        str1 += " to";
        System.out.println("Modified string: " + str1);

        // Reassigning the original string to a new value
        str1 = "JAVA Programming";
        System.out.println("New string: " + str1);
    }
}

