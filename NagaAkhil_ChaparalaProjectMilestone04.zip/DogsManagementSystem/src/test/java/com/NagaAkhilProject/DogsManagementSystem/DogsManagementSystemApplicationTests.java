package com.NagaAkhilProject.DogsManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
/**
 * 
 * @author S549701 - Naga Akhil Chaparala
 *
 */
@SpringBootTest
class DogsManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
