package com.NagaAkhilProject.SampleWebAppDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SampleWebAppDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
