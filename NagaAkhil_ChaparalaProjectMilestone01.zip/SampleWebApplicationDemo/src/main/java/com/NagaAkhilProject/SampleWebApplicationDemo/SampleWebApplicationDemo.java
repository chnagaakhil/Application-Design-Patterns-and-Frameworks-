package com.NagaAkhilProject.SampleWebApplicationDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
/**
 * 
 * @author S549701 - Naga Akhil Chaparala
 *
 */
@SpringBootApplication
public class SampleWebApplicationDemo {

	public static void main(String[] args) {
		SpringApplication.run(SampleWebApplicationDemo.class, args);
	}

}
