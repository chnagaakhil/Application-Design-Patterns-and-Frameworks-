package com.NagaAkhilProject.ParametersDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
/**
 * 
 * @author S549701 - Naga Akhil Chaparala
 *
 */
@SpringBootApplication
public class ParametersDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParametersDemoApplication.class, args);
	}

}
